package com.mimi.FoodDelivery.repositories;

import com.mimi.FoodDelivery.entities.Deals;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DealsRepository extends JpaRepository<Deals,Long> {

}
